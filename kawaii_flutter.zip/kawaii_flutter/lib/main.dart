import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(title: 'Kawaii Food', home: LoginScreen());
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  void login() async {
    String username = usernameController.text;
    String password = passwordController.text;

    final url = Uri.parse('http://localhost/kawaiifood/login.php');

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'username': username, 'password': password}),
      );

      final result = json.decode(response.body);

      if (result['code'] == 1) {
        int accountId = result['account_id'];

        final cartResponse = await http.post(
          Uri.parse('http://localhost/kawaiifood/shoppingbag.php'),
          headers: {'Content-Type': 'application/json'},
          body: json.encode({'account_id': accountId}),
        );

        if (cartResponse.statusCode == 200) {
          int shoppingbagId = json.decode(cartResponse.body)['shoppingbag_id'];

          Navigator.push(
            context,
            MaterialPageRoute(
              builder:
                  (_) => ProductsScreen(
                    shoppingbagId: shoppingbagId,
                    accountId: accountId,
                  ),
            ),
          );
        }
      } else {
        showError(result['message']);
      }
    } catch (_) {
      showError("Errore di rete");
    }
  }

  void showError(String msg) {
    showDialog(
      context: context,
      builder:
          (ctx) => AlertDialog(
            title: Text("Errore"),
            content: Text(msg),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(),
                child: Text("OK"),
              ),
            ],
          ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text("Login")),
    body: Padding(
      padding: const EdgeInsets.all(250),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TextField(
            controller: usernameController,
            decoration: InputDecoration(labelText: 'Username'),
          ),
          TextField(
            controller: passwordController,
            obscureText: true,
            decoration: InputDecoration(labelText: 'Password'),
          ),
          SizedBox(height: 20),
          ElevatedButton(onPressed: login, child: Text("Login")),
        ],
      ),
    ),
  );
}

class ProductsScreen extends StatefulWidget {
  final int shoppingbagId;
  final int accountId;
  const ProductsScreen({
    super.key,
    required this.shoppingbagId,
    required this.accountId,
  });
  @override
  _ProductsScreenState createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  List products = [];
  Map<int, int> productQuantities = {};

  @override
  void initState() {
    super.initState();
    fetchProducts();
  }

  Future<void> fetchProducts() async {
    final response = await http.get(
      Uri.parse('http://localhost/kawaiifood/get_product.php'),
    );
    if (response.statusCode == 200) {
      setState(() => products = json.decode(response.body));
    }
  }

  Future<void> addToCart(int productId, int quantity) async {
    await http.put(
      Uri.parse('http://localhost/kawaiifood/shoppingbag_row.php'),
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: {
        'shoppingbag_id': widget.shoppingbagId.toString(),
        'product_id': productId.toString(),
        'quantity': quantity.toString(),
      },
    );
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text("Aggiunto al carrello")));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text("Prodotti"),
      actions: [
        IconButton(
          icon: Icon(Icons.shopping_cart),
          onPressed:
              () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder:
                      (_) => CartScreen(
                        shoppingbagId: widget.shoppingbagId,
                        accountId: widget.accountId,
                      ),
                ),
              ),
        ),
      ],
    ),
    body:
        products.isEmpty
            ? Center(child: CircularProgressIndicator())
            : ListView.builder(
              itemCount: products.length,
              itemBuilder: (ctx, index) {
                final product = products[index];
                final productId = int.parse(product['id'].toString());
                final quantity = productQuantities[productId] ?? 0;
                return Card(
                  margin: EdgeInsets.all(10),
                  child: Column(
                    children: [
                      Image.network(
                        "http://localhost/kawaiifood/images/${product['file']}",
                        height: 100,
                      ),
                      ListTile(
                        title: Text(product['name']),
                        subtitle: Text("€${product['price']}"),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          IconButton(
                            onPressed:
                                () => setState(
                                  () =>
                                      productQuantities[productId] =
                                          (quantity - 1).clamp(0, 99),
                                ),
                            icon: Icon(Icons.remove),
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 20),
                            child: Text('$quantity'),
                          ),
                          IconButton(
                            onPressed:
                                () => setState(
                                  () =>
                                      productQuantities[productId] =
                                          quantity + 1,
                                ),
                            icon: Icon(Icons.add),
                          ),
                        ],
                      ),
                      if (quantity > 0)
                        ElevatedButton.icon(
                          icon: Icon(Icons.add_shopping_cart),
                          label: Text("Aggiungi al carrello"),
                          onPressed: () => addToCart(productId, quantity),
                        ),
                    ],
                  ),
                );
              },
            ),
  );
}

class CartScreen extends StatefulWidget {
  final int shoppingbagId;
  final int accountId;
  const CartScreen({
    super.key,
    required this.shoppingbagId,
    required this.accountId,
  });
  @override
  _CartScreenState createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  List cartItems = [];

  @override
  void initState() {
    super.initState();
    fetchCart();
  }

  Future<void> fetchCart() async {
    final response = await http.get(
      Uri.parse(
        'http://localhost/kawaiifood/shoppingbag.php?shoppingbag_id=${widget.shoppingbagId}',
      ),
    );
    if (response.statusCode == 200) {
      setState(() => cartItems = json.decode(response.body));
    }
  }

  Future<void> deleteItem(int productId) async {
    await http.delete(
      Uri.parse('http://localhost/kawaiifood/shoppingbag_row.php'),
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: 'shoppingbag_id=${widget.shoppingbagId}&product_id=$productId',
    );
    fetchCart();
  }

  Future<void> clearCart() async {
    await http.delete(
      Uri.parse(
        'http://localhost/kawaiifood/shoppingbag.php?shoppingbag_id=${widget.shoppingbagId}',
      ),
    );
    fetchCart();
  }

  Future<void> closeCart() async {
    final response = await http.post(
      Uri.parse('http://localhost/kawaiifood/orders.php'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'shoppingbag_id': widget.shoppingbagId,
        'account_id': widget.accountId,
      }),
    );
    if (response.statusCode == 200) {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text("Carrello"),
      actions: [
        IconButton(icon: Icon(Icons.delete_forever), onPressed: clearCart),
        IconButton(icon: Icon(Icons.check), onPressed: closeCart),
        IconButton(
          icon: Icon(Icons.receipt),
          onPressed:
              () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => OrdersScreen(accountId: widget.accountId),
                ),
              ),
        ),
      ],
    ),
    body:
        cartItems.isEmpty
            ? Center(child: Text("Carrello vuoto"))
            : ListView.builder(
              itemCount: cartItems.length,
              itemBuilder: (ctx, i) {
                final item = cartItems[i];
                final productId = item['product_id'];
                if (productId == null) return SizedBox();
                return ListTile(
                  leading: Text("${item['quantity']}x"),
                  title: Text(item['name']),
                  subtitle: Text("€${item['price']}"),
                  trailing: IconButton(
                    icon: Icon(Icons.delete),
                    onPressed: () => deleteItem(productId),
                  ),
                );
              },
            ),
  );
}

class OrdersScreen extends StatelessWidget {
  final int accountId;
  const OrdersScreen({super.key, required this.accountId});

  Future<List> fetchOrders() async {
    final response = await http.get(
      Uri.parse('http://localhost/kawaiifood/orders.php?account_id=$accountId'),
    );
    if (response.statusCode == 200) {
      return json.decode(response.body);
    }
    return [];
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text("I tuoi ordini")),
    body: FutureBuilder(
      future: fetchOrders(),
      builder: (ctx, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting)
          return Center(child: CircularProgressIndicator());
        final orders = snapshot.data as List;
        return ListView.builder(
          itemCount: orders.length,
          itemBuilder: (ctx, i) {
            final o = orders[i];
            final int quantity = int.parse(o['quantity'].toString());
            final double price = double.parse(o['price'].toString());
            final double total = quantity * price;
            return ListTile(
              title: Text("${quantity} x ${o['name']}"),
              subtitle: Text("Ordine #${o['order_id']}"),
              trailing: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text("€${price.toStringAsFixed(2)} cad."),
                  Text(
                    "Tot: €${total.toStringAsFixed(2)}",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            );
          },
        );
      },
    ),
  );
}
